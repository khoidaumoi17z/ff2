# Build Inspector khi không có Mac

Dùng máy macOS do GitHub Actions cung cấp. Bạn thao tác trên trang GitHub bằng trình duyệt; không cần tự cài Xcode. Gói kết quả là **IPA chưa ký của ứng dụng kiểm tra tệp**, không phải ứng dụng inject game. Cần ký ứng dụng hợp lệ để cài lên iPhone.

## Thiết lập từ iPhone

1. Tải `VNBAPEX-Inspector-source.zip` được gửi cùng hướng dẫn này. Giữ nguyên tên tệp và giữ nguyên dạng ZIP.
2. Đăng nhập GitHub trong Safari và tạo repository do bạn sở hữu. Nếu chọn repository riêng tư, kiểm tra hạn mức Actions của tài khoản trước khi chạy; hướng dẫn không tự kích hoạt thanh toán.
3. Trong repository, chọn Add file → Upload files. Tải **nguyên tệp ZIP** lên thư mục gốc và commit. Không cần giải nén hay tải từng tệp Swift.
4. Giải nén một bản ZIP trong ứng dụng Tệp để đọc `VNBAPEX-Inspector/Workflow/ios-build.yml`. Hoặc dùng bản workflow riêng được gửi cùng gói.
5. Trên GitHub, chọn Add file → Create new file. Nhập đường dẫn `.github/workflows/ios-build.yml`, dán toàn bộ nội dung workflow, rồi commit vào nhánh mặc định. Nếu không thấy các nút trên màn hình nhỏ, chuyển Safari sang chế độ trang web cho máy tính.
6. Mở tab Actions → Build Inspector IPA → Run workflow. Workflow chỉ chạy khi bạn bấm nút này.
7. Khi job hoàn tất, mở lần chạy và tải artifact `VNBAPEXInspector-unsigned-IPA`. Giải nén artifact để lấy `VNBAPEXInspector-unsigned.ipa` và `SHA256.txt`.

Workflow tải mã nguồn từ repository của bạn, giải nén ZIP, kiểm tra dự án, chạy XCTest trên một iPhone Simulator có sẵn, rồi build cho iOS thật và đóng gói IPA chưa ký. Nếu kiểm thử hoặc build thất bại, workflow không đưa ra artifact IPA thành công. Mở artifact `Inspector-build-logs` để xem lỗi.

## Những gì chưa làm thay bạn

- Chưa tạo repository hoặc chạy workflow trong tài khoản GitHub của bạn.
- Đã nhận log một lần build trên macOS do người dùng chạy: bản trước thất bại ở bước biên dịch SwiftUI. Nguồn hiện tại đã sửa theo log nhưng chưa được build/XCTest lại. Xem `FIX-NOTES.md`.
- Chưa có chứng chỉ/provisioning và chưa ký IPA. Một IPA chưa ký không thể cài trực tiếp lên iPhone thông thường.
- Không phát hành lên App Store, TestFlight hoặc gửi tệp tới dịch vụ ký nào.

Không cần nhập chứng chỉ, mật khẩu hay secret vào workflow chưa ký này. Không gửi khóa riêng cho người khác. Để ký và phân phối hợp lệ, dùng quy trình phù hợp với tài khoản và thiết bị của bạn; xem hướng dẫn Apple bên dưới.

## Tài liệu gốc

- Máy chạy do GitHub cung cấp: https://docs.github.com/en/actions/reference/runners/github-hosted-runners
- Cách workflow được kích hoạt thủ công: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow
- Các phiên bản Xcode trong image macOS: https://github.com/actions/runner-images/blob/main/images/macos/macos-15-arm64-Readme.md
- Artifact đầu ra: https://github.com/actions/upload-artifact
- Ký và phân phối ứng dụng: https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases
