import XCTest
@testable import VNBAPEXInspector

final class InspectionTests: XCTestCase {
    private func inspect(_ data: Data) throws -> InspectedFile {
        try InspectedFile(record: FileRecord(id: UUID(), name: "fixture.json", importedAt: Date(timeIntervalSince1970: 0)), data: data)
    }

    func testEmptyFileHasKnownDigestAndIsNotJSON() throws {
        let file = try inspect(Data())
        XCTAssertEqual(file.digest, "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
        XCTAssertFalse(file.jsonValid)
        XCTAssertEqual(file.totalStrings, 0)
        XCTAssertEqual(file.hexadecimalPreview, "")
    }

    func testValidJSONAndUnicode() throws {
        let file = try inspect(Data("{\"enabled\":true,\"label\":\"Tiếng Việt\"}".utf8))
        XCTAssertTrue(file.jsonValid)
        XCTAssertEqual(file.rootKeys, ["enabled", "label"])
        XCTAssertTrue(file.jsonPreview?.contains("Tiếng Việt") == true)
    }

    func testExtensionDoesNotMakeSourceCodeValidJSON() throws {
        let file = try inspect(Data("public class Example { }".utf8))
        XCTAssertFalse(file.jsonValid)
        XCTAssertNil(file.jsonPreview)
    }

    func testJSONScalarIsAccepted() throws {
        let file = try inspect(Data("true".utf8))
        XCTAssertTrue(file.jsonValid)
        XCTAssertTrue(file.rootKeys.isEmpty)
    }

    func testBinaryStringIndicatorsDoNotRequireValidJSON() throws {
        let file = try inspect(Data([0, 255]) + Data("UnityEngine".utf8) + Data([0]))
        XCTAssertFalse(file.jsonValid)
        XCTAssertEqual(file.strings, ["UnityEngine"])
        XCTAssertEqual(file.signals, ["UnityEngine"])
    }

    func testComparisonCountsChangedAndTrailingBytesSeparately() {
        let result = ByteComparison.compare(Data([1, 2, 3]), Data([1, 9, 3, 4]))
        XCTAssertFalse(result.identical)
        XCTAssertEqual(result.differentAtSharedOffsets, 1)
        XCTAssertEqual(result.firstOffsets, [1])
        XCTAssertEqual(result.trailingBytesInLeft, 0)
        XCTAssertEqual(result.trailingBytesInRight, 1)
        XCTAssertTrue(ByteComparison.compare(Data(), Data()).identical)
    }

    func testOversizedFileIsRejected() {
        XCTAssertThrowsError(try inspect(Data(repeating: 0, count: InspectedFile.maximumBytes + 1)))
    }

    func testStringPreviewCapsWithoutLosingTotalCount() throws {
        let data = Data((0..<140).map { "string-\($0)" }.joined(separator: "\u{0}").utf8)
        let file = try inspect(data)
        XCTAssertEqual(file.totalStrings, 140)
        XCTAssertEqual(file.strings.count, 128)
    }
}
