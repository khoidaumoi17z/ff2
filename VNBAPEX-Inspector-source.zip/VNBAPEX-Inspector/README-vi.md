# VNBAPEX Inspector

Ứng dụng SwiftUI độc lập để kiểm tra tệp trên iPhone/iPad. Đây là **dự án nguồn Xcode**, chưa phải IPA đã biên dịch hoặc ký. Trong môi trường tạo dự án không có Xcode/iOS SDK, nên chưa chạy build, XCTest hoặc kiểm thử giao diện trên iOS.

**Không có Mac:** đã thêm workflow GitHub Actions để build trên máy macOS của dịch vụ. Đọc `BUILD-GITHUB-vi.md`. Chỉ cần đưa nguyên ZIP mã nguồn lên repository và thêm workflow; không cần tải từng tệp Swift. Kết quả là IPA chưa ký, vẫn cần ký hợp lệ để cài. Người dùng đã gửi log của lần build đầu, có lỗi SwiftUI; bản nguồn hiện tại đã sửa theo log nhưng chưa được build lại. Xem `FIX-NOTES.md` để cập nhật ZIP trên GitHub.

## Có gì trong ứng dụng

- Nhập tệp từ ứng dụng Tệp, tối đa 8 MiB/tệp và 6 tệp đang lưu.
- Lưu bản sao trong vùng dữ liệu riêng của ứng dụng; thao tác xóa chỉ xóa bản sao đó.
- Hiển thị tên, số byte, ngày nhập và SHA-256.
- Kiểm tra cú pháp JSON và xem nội dung đã định dạng. Phần xem trước giới hạn 32.768 ký tự.
- Trích xuất chuỗi ASCII dài từ 5 ký tự; xem tối đa 128 chuỗi, mỗi chuỗi tối đa 384 ký tự.
- Hiển thị một số dấu vết tên và 256 byte đầu dưới dạng hex.
- So sánh hai tệp theo offset, tách byte khác nhau và phần dư ở cuối.
- Chia sẻ báo cáo văn bản qua bảng chia sẻ iOS. Hãy kiểm tra nội dung trước khi chọn ứng dụng nhận.
- Màn hình mô phỏng khung, nhãn và đường nối với ba điểm cố định.

Ứng dụng không thực thi patch, không sửa tệp gốc, không truy cập dữ liệu của game và không có kết nối mạng. Mô phỏng không dùng dữ liệu từ Free Fire. Tên tìm thấy trong tệp và JSON hợp lệ không chứng minh tính năng hoạt động; SHA-256 không xác nhận tác giả hoặc độ an toàn.

## Mở và chạy

1. Dùng máy Mac có Xcode 16 hoặc mới hơn và iOS SDK phù hợp. Dự án đặt mức hệ điều hành tối thiểu là iOS 16.
2. Giải nén gói, mở `VNBAPEXInspector.xcodeproj`.
3. Chọn scheme `VNBAPEXInspector` và một iPhone Simulator có sẵn. Bấm Run.
4. Để chạy trên iPhone thật, vào target `VNBAPEXInspector` → Signing & Capabilities, chọn Team của bạn. Đổi Bundle Identifier nếu định danh hiện tại đã được dùng. Chọn thiết bị và bấm Run; hoàn tất thiết lập thiết bị mà Xcode yêu cầu.
5. Trong ứng dụng, dùng “Thử với tệp mẫu” hoặc “Nhập patch hoặc cấu hình”.

Không gửi chứng chỉ, khóa riêng hoặc mật khẩu tài khoản để cấu hình dự án.

## Kiểm tra bằng dòng lệnh trên Mac

```bash
python3 tools/verify_project.py
bash build.sh simulator
```

Chạy XCTest sau khi chọn simulator có sẵn:

```bash
xcrun simctl list devices available
bash build.sh test SIMULATOR_UDID
```

`SIMULATOR_UDID` là UDID thực của simulator trên máy bạn. Có thể chạy cùng bộ kiểm thử bằng Product → Test trong Xcode.

Có 8 kiểm thử nguồn cho SHA-256 tệp rỗng, JSON/Unicode, văn bản giả JSON, JSON scalar, chuỗi nhị phân, so sánh byte, giới hạn dung lượng và giới hạn xem trước. Chưa chạy các kiểm thử Swift trong môi trường tạo dự án; không có kết quả XCTest thành công được xác nhận.

## Tạo archive và xuất IPA

Sau khi build, chạy và kiểm thử thành công trên Mac:

```bash
bash build.sh archive YOUR_TEAM_ID
```

Hoặc chọn thiết bị iOS phù hợp rồi Product → Archive. Trong Organizer, chọn archive và Distribute App; chọn phương thức xuất phù hợp với tài khoản và provisioning của bạn. Có thể cần đăng ký thiết bị hoặc chứng chỉ phân phối tùy phương thức. Script không tự upload hay phát hành ứng dụng.

Quy trình tạo archive và phân phối của Apple: https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases

## Dữ liệu và minh bạch

Các tệp bạn gửi trong cuộc trò chuyện không được đóng gói vào ứng dụng. Thư mục `Samples` chỉ chứa dữ liệu thử vô hại. Người dùng tự chọn tệp cần xem trên thiết bị.

Tệp nhập được đọc với giới hạn dung lượng, rồi sao chép vào `Application Support/InspectorFiles` trong container của chính ứng dụng. Tên lưu là UUID do ứng dụng tạo. Tệp gốc không bị ghi đè. Dữ liệu lưu có tùy chọn bảo vệ tệp đầy đủ khi thiết bị khóa. Không có SDK bên thứ ba hoặc package từ xa.

API Apple dùng trong dự án:

- File importer: https://developer.apple.com/documentation/swiftui/view/fileimporter(ispresented:allowedcontenttypes:oncompletion:)
- Quyền đọc tệp người dùng chọn: https://developer.apple.com/documentation/foundation/url/startaccessingsecurityscopedresource()
- Chia sẻ báo cáo: https://developer.apple.com/documentation/swiftui/sharelink
- Mã băm: https://developer.apple.com/documentation/cryptokit/hashfunction

## Các tệp chính

| Tệp | Vai trò |
|---|---|
| `Inspection.swift` | Đọc có giới hạn, SHA-256, JSON, chuỗi, so sánh byte, kho bản sao |
| `InspectorStore.swift` | Trạng thái giao diện và thao tác nhập/xóa bất đồng bộ |
| `VNBAPEXInspectorApp.swift` | Ba tab giao diện SwiftUI |
| `InspectionTests.swift` | Bộ kiểm thử XCTest |
| `project.pbxproj` và shared scheme | Dự án Xcode, target ứng dụng và target kiểm thử |
| `tools/verify_project.py` | Kiểm tra cấu trúc PBX, plist, scheme và asset |
| `VALIDATION.md` | Kết quả kiểm tra có thể thực hiện trong môi trường tạo dự án |

Ghi nguồn trong mã nguồn và tài liệu: VNBAPEX. Tên bundle mẫu là `com.vnbapex.inspector`.
