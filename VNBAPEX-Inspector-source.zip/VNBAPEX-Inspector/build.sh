#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "Cần chạy script trên máy Mac đã cài Xcode và iOS SDK." >&2
  exit 1
fi
project_args=(-project VNBAPEXInspector.xcodeproj -scheme VNBAPEXInspector)
case "${1:-simulator}" in
  simulator)
    xcodebuild "${project_args[@]}" -configuration Debug \
      -destination 'generic/platform=iOS Simulator' \
      -derivedDataPath Build/DerivedData CODE_SIGNING_ALLOWED=NO build
    ;;
  test)
    if [[ -z "${2:-}" ]]; then echo "Cách dùng: bash build.sh test SIMULATOR_UDID" >&2; exit 1; fi
    xcodebuild "${project_args[@]}" -configuration Debug \
      -destination "platform=iOS Simulator,id=$2" \
      -derivedDataPath Build/DerivedData CODE_SIGNING_ALLOWED=NO test
    ;;
  archive)
    if [[ -z "${2:-}" ]]; then echo "Cách dùng: bash build.sh archive YOUR_TEAM_ID" >&2; exit 1; fi
    xcodebuild "${project_args[@]}" -configuration Release \
      -destination 'generic/platform=iOS' -archivePath Build/VNBAPEXInspector.xcarchive \
      "DEVELOPMENT_TEAM=$2" archive
    ;;
  archive-unsigned)
    xcodebuild "${project_args[@]}" -configuration Release \
      -destination 'generic/platform=iOS' -archivePath Build/VNBAPEXInspector-unsigned.xcarchive \
      CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= archive
    task_package_dir=$(mktemp -d "${TMPDIR:-/tmp}/vnbapex-package.XXXXXX")
    trap 'rm -rf "$task_package_dir"' EXIT
    mkdir -p "$task_package_dir/Payload"
    ditto Build/VNBAPEXInspector-unsigned.xcarchive/Products/Applications/VNBAPEXInspector.app \
      "$task_package_dir/Payload/VNBAPEXInspector.app"
    mkdir -p Build/Artifacts
    ditto -c -k --keepParent "$task_package_dir/Payload" Build/Artifacts/VNBAPEXInspector-unsigned.ipa
    shasum -a 256 Build/Artifacts/VNBAPEXInspector-unsigned.ipa > Build/Artifacts/SHA256.txt
    echo "Đã đóng gói IPA CHƯA KÝ. Cần ký hợp lệ trước khi cài lên iPhone."
    ;;
  *) echo "Chọn simulator, test, archive hoặc archive-unsigned." >&2; exit 1 ;;
esac
