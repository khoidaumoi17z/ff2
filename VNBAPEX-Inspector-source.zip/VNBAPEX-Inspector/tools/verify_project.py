"""Checks project structure only; this is not a Swift compiler or iOS test."""
from pathlib import Path
import json
import plistlib
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
TOKEN = re.compile(r'\s+|//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|[{}()=;,]|[^\s{}()=;,]+', re.S)

def parse_openstep(text):
    tokens = [m.group() for m in TOKEN.finditer(text)
              if not m.group().isspace() and not m.group().startswith(('//', '/*'))]
    index = 0
    def take(expected=None):
        nonlocal index
        value = tokens[index]
        index += 1
        if expected is not None:
            assert value == expected, (value, expected)
        return value
    def value():
        token = take()
        if token == '{':
            result = {}
            while tokens[index] != '}':
                key = take()
                if key.startswith('"'): key = json.loads(key)
                take('=')
                assert key not in result, ('duplicate key', key)
                result[key] = value()
                take(';')
            take('}')
            return result
        if token == '(':
            result = []
            while tokens[index] != ')':
                result.append(value())
                if tokens[index] == ',': take(',')
                else: assert tokens[index] == ')'
            take(')')
            return result
        return json.loads(token) if token.startswith('"') else token
    result = value()
    assert index == len(tokens), 'trailing tokens'
    return result

def validate():
    project_path = ROOT / 'VNBAPEXInspector.xcodeproj/project.pbxproj'
    project = parse_openstep(project_path.read_text())
    objects = project['objects']
    assert objects[project['rootObject']]['isa'] == 'PBXProject'
    def walk(item):
        if isinstance(item, dict):
            for value in item.values(): walk(value)
        elif isinstance(item, list):
            for value in item: walk(value)
        elif isinstance(item, str) and re.fullmatch(r'[0-9A-F]{24}', item):
            assert item in objects, ('missing object', item)
    walk(project)
    root = objects[project['rootObject']]
    assert len(root['targets']) == 2
    assert {objects[t]['productType'] for t in root['targets']} == {
        'com.apple.product-type.application', 'com.apple.product-type.bundle.unit-test'}
    def check_group(group_id, directory):
        group = objects[group_id]
        if 'path' in group: directory = directory / group['path']
        for child_id in group.get('children', []):
            child = objects[child_id]
            if child['isa'] == 'PBXGroup': check_group(child_id, directory)
            elif child.get('sourceTree') != 'BUILT_PRODUCTS_DIR':
                assert (directory / child['path']).exists(), child['path']
    check_group(root['mainGroup'], ROOT)
    for obj in objects.values():
        if obj['isa'] == 'PBXSourcesBuildPhase':
            assert obj['files'], 'empty sources phase'
            for build in obj['files']:
                assert objects[objects[build]['fileRef']]['path'].endswith('.swift')
    for name in ['Info.plist', 'PrivacyInfo.xcprivacy']:
        with (ROOT / 'VNBAPEXInspector' / name).open('rb') as handle: plistlib.load(handle)
    scheme = ET.parse(ROOT / 'VNBAPEXInspector.xcodeproj/xcshareddata/xcschemes/VNBAPEXInspector.xcscheme')
    for reference in scheme.findall('.//BuildableReference'):
        target = objects[reference.attrib['BlueprintIdentifier']]
        assert target['isa'] == 'PBXNativeTarget'
        assert target['name'] == reference.attrib['BlueprintName']
    assert scheme.findall('.//TestableReference'), 'no test target in scheme'
    for source in (ROOT / 'Samples').glob('*.json'): json.loads(source.read_text())
    asset = ROOT / 'VNBAPEXInspector/Assets.xcassets/AppIcon.appiconset'
    metadata = json.loads((asset / 'Contents.json').read_text())
    png = (asset / metadata['images'][0]['filename']).read_bytes()
    assert png[:8] == b'\x89PNG\r\n\x1a\n'
    import struct
    assert struct.unpack('>II', png[16:24]) == (1024, 1024)
    assert png[25] == 2, 'icon must be RGB without alpha'
    print(f'PASS: {len(objects)} PBX objects, source paths, target references, plists, shared scheme, samples, icon.')
    print('NOT RUN: Swift compilation, XCTest, Simulator/device UI, code signing, IPA export.')

if __name__ == '__main__': validate()
