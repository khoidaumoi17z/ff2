# Trạng thái kiểm tra

Ngày tạo: 30/09/2026.

## Đã thực hiện

- Đọc lại cấu trúc OpenStep của `project.pbxproj`: 39 object, không có khóa trùng hoặc tham chiếu object bị thiếu.
- Kiểm tra đường dẫn nguồn, hai target (ứng dụng và unit test), các build phase và shared scheme.
- Parse `Info.plist`, `PrivacyInfo.xcprivacy` và JSON của các asset/tệp mẫu.
- Kiểm tra icon PNG RGB 1024×1024, không có kênh alpha.
- Kiểm tra cú pháp shell của `build.sh` bằng `bash -n`.
- Parse workflow GitHub Actions, kiểm tra các khối shell và cú pháp Python nhúng. Workflow chỉ kích hoạt thủ công và sử dụng quyền đọc repository.
- Kiểm tra tệp ZIP không hỏng và các thành phần quan trọng có mặt trước khi gửi.

Lệnh kiểm tra cấu trúc: `python3 tools/verify_project.py`.

## Chưa thực hiện

- Biên dịch hoặc type-check Swift bằng Xcode.
- Chạy 8 kiểm thử XCTest đã viết.
- Chạy Simulator hoặc iPhone thật, kiểm tra giao diện/tương tác/khôi phục dữ liệu.
- Ký ứng dụng, tạo archive hay xuất IPA.

Lý do: môi trường tạo dự án không có Xcode/iOS SDK/Swift compiler hoặc thiết bị iOS. Vì vậy, kết quả kiểm tra cấu trúc không được xem là xác nhận dự án đã build thành công. Cần hoàn tất build và kiểm thử trên Mac trước khi dùng trên thiết bị.

Có thể dùng máy macOS do GitHub Actions cung cấp thay vì Mac cá nhân. Trạng thái lần chạy do người dùng thực hiện được ghi ở phần cập nhật dưới đây.

## Cập nhật sau log GitHub được gửi

Người dùng đã chạy workflow và gửi test.log. Bản trước đã đến bước biên dịch Swift trên Xcode 16.4 nhưng thất bại do cách gọi Section có footer và lỗi kiểm tra kiểu ở CompareView. Bộ kiểm thử chưa chạy vì build thất bại. Đã sửa nguồn theo log; bản sửa chưa được build lại trên macOS. Xem FIX-NOTES.md.
